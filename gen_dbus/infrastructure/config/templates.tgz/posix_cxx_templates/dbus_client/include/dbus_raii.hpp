/*
 * dbus_raii.hpp
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 * Distributed under terms of the GNU General Public License v3.0.
 */
#pragma once

#include <dbus/dbus.h>
#include <memory>
#include <stdexcept>
#include <string>

namespace ${PRO_LOWER}::dbus {

class DBusErrorGuard final {
public:
    DBusErrorGuard() noexcept {
        dbus_error_init(&err_);
    }

    ~DBusErrorGuard() noexcept {
        if (dbus_error_is_set(&err_)) {
            dbus_error_free(&err_);
        }
    }

    DBusErrorGuard(const DBusErrorGuard&) = delete;
    DBusErrorGuard& operator=(const DBusErrorGuard&) = delete;

    [[nodiscard]] DBusError* get() noexcept {
        return &err_;
    }

    [[nodiscard]] bool is_set() const noexcept {
        return dbus_error_is_set(&err_) != FALSE;
    }

    void throw_if_set(const std::string& context) const {
        if (is_set()) {
            throw std::runtime_error(
                context + ": " + (err_.name ? err_.name : "DBusError") +
                " - " + (err_.message ? err_.message : "unknown error")
            );
        }
    }

private:
    DBusError err_{};
};

struct MessageDeleter {
    void operator()(DBusMessage* msg) const noexcept {
        if (msg != nullptr) {
            dbus_message_unref(msg);
        }
    }
};

struct ConnectionDeleter {
    void operator()(DBusConnection* conn) const noexcept {
        if (conn != nullptr) {
            dbus_connection_unref(conn);
        }
    }
};

using UniqueMessage = std::unique_ptr<DBusMessage, MessageDeleter>;
using UniqueConnection = std::unique_ptr<DBusConnection, ConnectionDeleter>;

} // namespace ${PRO_LOWER}::dbus
