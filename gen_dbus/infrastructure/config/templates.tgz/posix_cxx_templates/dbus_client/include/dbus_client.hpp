/*
 * dbus_client.hpp
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 * Distributed under terms of the GNU General Public License v3.0.
 */
#pragma once

#include "dbus_raii.hpp"
#include <cstdint>
#include <string>
#include <string_view>

namespace ${PRO_LOWER}::dbus {

class ${PRO_PASCAL}Client final {
public:
    static constexpr std::string_view kBusName = "org.vroncevic.${PRO_LOWER}.Service";
    static constexpr std::string_view kObjectPath = "/org/vroncevic/${PRO_LOWER}/Object";
    static constexpr std::string_view kInterfaceName = "org.vroncevic.${PRO_LOWER}.Control";

    ${PRO_PASCAL}Client();
    ~${PRO_PASCAL}Client();

    ${PRO_PASCAL}Client(const ${PRO_PASCAL}Client&) = delete;
    ${PRO_PASCAL}Client& operator=(const ${PRO_PASCAL}Client&) = delete;

    [[nodiscard]] std::string introspect();
    [[nodiscard]] std::string ping(const std::string& message);
    [[nodiscard]] bool set_status(const std::string& new_status);
    [[nodiscard]] std::string get_status_property();
    void set_status_property(const std::string& new_status);
    [[nodiscard]] std::uint32_t get_call_count_property();
    void drain_signals(int timeout_ms);

private:
    static DBusHandlerResult signal_filter(
        DBusConnection* conn,
        DBusMessage* msg,
        void* user_data
    ) noexcept;

    UniqueConnection conn_{};
    std::uint32_t signals_received_{0U};
};

} // namespace ${PRO_LOWER}::dbus
