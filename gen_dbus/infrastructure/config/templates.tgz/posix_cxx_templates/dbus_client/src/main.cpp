/*
 * main.cpp
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 * Distributed under terms of the GNU General Public License v3.0.
 */
#include "dbus_client.hpp"
#include <cstdlib>
#include <iostream>

int main() {
    try {
        ${PRO_LOWER}::dbus::${PRO_PASCAL}Client client;
        const std::string xml = client.introspect();
        std::cout << "[client] Introspection XML bytes: " << xml.size() << "\n";
        std::cout << "[client] Initial Status property: " << client.get_status_property() << "\n";

        const std::string pong = client.ping("hello from C++20 RAII client");
        std::cout << "[client] Ping reply: " << pong << "\n";

        const bool applied = client.set_status("active");
        std::cout << "[client] SetStatus('active') applied: " << (applied ? "true" : "false") << "\n";

        client.set_status_property("ready");
        client.drain_signals(150);

        std::cout << "[client] Final Status: " << client.get_status_property()
                  << " | CallCount: " << client.get_call_count_property() << "\n";
        return EXIT_SUCCESS;
    } catch (const std::exception& ex) {
        std::cerr << "[client] Error: " << ex.what() << "\n";
        return EXIT_FAILURE;
    }
}
