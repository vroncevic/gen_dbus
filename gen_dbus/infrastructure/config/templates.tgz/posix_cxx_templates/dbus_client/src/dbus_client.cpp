/*
 * dbus_client.cpp
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 * Distributed under terms of the GNU General Public License v3.0.
 */
#include "dbus_client.hpp"
#include <iostream>

namespace ${PRO_LOWER}::dbus {

namespace {

constexpr const char* kStatusMatchRule =
    "type='signal',interface='org.vroncevic.${PRO_LOWER}.Control',member='StatusChanged'";

} // namespace

${PRO_PASCAL}Client::${PRO_PASCAL}Client() {
    DBusErrorGuard err;
    conn_.reset(dbus_bus_get(${C_BUS_CONST}, err.get()));
    err.throw_if_set("dbus_bus_get");
    if (!conn_) {
        throw std::runtime_error("Failed to acquire D-Bus client connection");
    }

    dbus_bus_add_match(conn_.get(), kStatusMatchRule, err.get());
    err.throw_if_set("dbus_bus_add_match");
    dbus_connection_add_filter(conn_.get(), &${PRO_PASCAL}Client::signal_filter, this, nullptr);
    dbus_connection_flush(conn_.get());
}

${PRO_PASCAL}Client::~${PRO_PASCAL}Client() {
    if (conn_) {
        dbus_connection_remove_filter(conn_.get(), &${PRO_PASCAL}Client::signal_filter, this);
        DBusErrorGuard err;
        dbus_bus_remove_match(conn_.get(), kStatusMatchRule, err.get());
    }
}

DBusHandlerResult ${PRO_PASCAL}Client::signal_filter(
    DBusConnection* /*conn*/,
    DBusMessage* msg,
    void* user_data
) noexcept {
    auto* self = static_cast<${PRO_PASCAL}Client*>(user_data);
    if (dbus_message_is_signal(msg, kInterfaceName.data(), "StatusChanged")) {
        DBusErrorGuard err;
        const char* old_status = nullptr;
        const char* new_status = nullptr;
        if (dbus_message_get_args(
                msg,
                err.get(),
                DBUS_TYPE_STRING, &old_status,
                DBUS_TYPE_STRING, &new_status,
                DBUS_TYPE_INVALID)) {
            ++self->signals_received_;
            std::cout << "[client] Signal StatusChanged: '"
                      << (old_status ? old_status : "") << "' -> '"
                      << (new_status ? new_status : "") << "'\n";
        }
        return DBUS_HANDLER_RESULT_HANDLED;
    }
    return DBUS_HANDLER_RESULT_NOT_YET_HANDLED;
}

std::string ${PRO_PASCAL}Client::introspect() {
    UniqueMessage req{dbus_message_new_method_call(
        kBusName.data(), kObjectPath.data(), DBUS_INTERFACE_INTROSPECTABLE, "Introspect"
    )};
    DBusErrorGuard err;
    UniqueMessage rep{dbus_connection_send_with_reply_and_block(conn_.get(), req.get(), 3000, err.get())};
    err.throw_if_set("Introspect");
    const char* xml = nullptr;
    if (!dbus_message_get_args(rep.get(), err.get(), DBUS_TYPE_STRING, &xml, DBUS_TYPE_INVALID)) {
        err.throw_if_set("Introspect args");
    }
    return xml != nullptr ? std::string{xml} : std::string{};
}

std::string ${PRO_PASCAL}Client::ping(const std::string& message) {
    UniqueMessage req{dbus_message_new_method_call(
        kBusName.data(), kObjectPath.data(), kInterfaceName.data(), "Ping"
    )};
    const char* msg_ptr = message.c_str();
    dbus_message_append_args(req.get(), DBUS_TYPE_STRING, &msg_ptr, DBUS_TYPE_INVALID);
    DBusErrorGuard err;
    UniqueMessage rep{dbus_connection_send_with_reply_and_block(conn_.get(), req.get(), 3000, err.get())};
    err.throw_if_set("Ping");
    const char* reply_str = nullptr;
    if (!dbus_message_get_args(rep.get(), err.get(), DBUS_TYPE_STRING, &reply_str, DBUS_TYPE_INVALID)) {
        err.throw_if_set("Ping args");
    }
    return reply_str != nullptr ? std::string{reply_str} : std::string{};
}

bool ${PRO_PASCAL}Client::set_status(const std::string& new_status) {
    UniqueMessage req{dbus_message_new_method_call(
        kBusName.data(), kObjectPath.data(), kInterfaceName.data(), "SetStatus"
    )};
    const char* status_ptr = new_status.c_str();
    dbus_message_append_args(req.get(), DBUS_TYPE_STRING, &status_ptr, DBUS_TYPE_INVALID);
    DBusErrorGuard err;
    UniqueMessage rep{dbus_connection_send_with_reply_and_block(conn_.get(), req.get(), 3000, err.get())};
    err.throw_if_set("SetStatus");
    dbus_bool_t applied = FALSE;
    if (!dbus_message_get_args(rep.get(), err.get(), DBUS_TYPE_BOOLEAN, &applied, DBUS_TYPE_INVALID)) {
        err.throw_if_set("SetStatus args");
    }
    return applied != FALSE;
}

std::string ${PRO_PASCAL}Client::get_status_property() {
    UniqueMessage req{dbus_message_new_method_call(
        kBusName.data(), kObjectPath.data(), DBUS_INTERFACE_PROPERTIES, "Get"
    )};
    const char* iface_ptr = kInterfaceName.data();
    const char* prop_ptr = "Status";
    dbus_message_append_args(
        req.get(),
        DBUS_TYPE_STRING, &iface_ptr,
        DBUS_TYPE_STRING, &prop_ptr,
        DBUS_TYPE_INVALID
    );
    DBusErrorGuard err;
    UniqueMessage rep{dbus_connection_send_with_reply_and_block(conn_.get(), req.get(), 3000, err.get())};
    err.throw_if_set("Properties.Get(Status)");

    DBusMessageIter root{};
    DBusMessageIter variant{};
    if (!dbus_message_iter_init(rep.get(), &root) ||
        dbus_message_iter_get_arg_type(&root) != DBUS_TYPE_VARIANT) {
        throw std::runtime_error("Properties.Get(Status) did not return a variant");
    }
    dbus_message_iter_recurse(&root, &variant);
    const char* val = nullptr;
    dbus_message_iter_get_basic(&variant, &val);
    return val != nullptr ? std::string{val} : std::string{};
}

void ${PRO_PASCAL}Client::set_status_property(const std::string& new_status) {
    UniqueMessage req{dbus_message_new_method_call(
        kBusName.data(), kObjectPath.data(), DBUS_INTERFACE_PROPERTIES, "Set"
    )};
    const char* iface_ptr = kInterfaceName.data();
    const char* prop_ptr = "Status";
    const char* status_ptr = new_status.c_str();
    DBusMessageIter root{};
    DBusMessageIter variant{};
    dbus_message_iter_init_append(req.get(), &root);
    dbus_message_iter_append_basic(&root, DBUS_TYPE_STRING, &iface_ptr);
    dbus_message_iter_append_basic(&root, DBUS_TYPE_STRING, &prop_ptr);
    dbus_message_iter_open_container(&root, DBUS_TYPE_VARIANT, "s", &variant);
    dbus_message_iter_append_basic(&variant, DBUS_TYPE_STRING, &status_ptr);
    dbus_message_iter_close_container(&root, &variant);

    DBusErrorGuard err;
    UniqueMessage rep{dbus_connection_send_with_reply_and_block(conn_.get(), req.get(), 3000, err.get())};
    err.throw_if_set("Properties.Set(Status)");
}

std::uint32_t ${PRO_PASCAL}Client::get_call_count_property() {
    UniqueMessage req{dbus_message_new_method_call(
        kBusName.data(), kObjectPath.data(), DBUS_INTERFACE_PROPERTIES, "Get"
    )};
    const char* iface_ptr = kInterfaceName.data();
    const char* prop_ptr = "CallCount";
    dbus_message_append_args(
        req.get(),
        DBUS_TYPE_STRING, &iface_ptr,
        DBUS_TYPE_STRING, &prop_ptr,
        DBUS_TYPE_INVALID
    );
    DBusErrorGuard err;
    UniqueMessage rep{dbus_connection_send_with_reply_and_block(conn_.get(), req.get(), 3000, err.get())};
    err.throw_if_set("Properties.Get(CallCount)");

    DBusMessageIter root{};
    DBusMessageIter variant{};
    if (!dbus_message_iter_init(rep.get(), &root) ||
        dbus_message_iter_get_arg_type(&root) != DBUS_TYPE_VARIANT) {
        throw std::runtime_error("Properties.Get(CallCount) did not return a variant");
    }
    dbus_message_iter_recurse(&root, &variant);
    dbus_uint32_t val = 0U;
    dbus_message_iter_get_basic(&variant, &val);
    return static_cast<std::uint32_t>(val);
}

void ${PRO_PASCAL}Client::drain_signals(int timeout_ms) {
    dbus_connection_read_write_dispatch(conn_.get(), timeout_ms);
}

} // namespace ${PRO_LOWER}::dbus
