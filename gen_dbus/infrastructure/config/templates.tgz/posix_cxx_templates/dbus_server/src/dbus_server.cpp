/*
 * dbus_server.cpp
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 * Distributed under terms of the GNU General Public License v3.0.
 */
#include "dbus_server.hpp"
#include <cstring>
#include <iostream>

namespace ${PRO_LOWER}::dbus {

namespace {

constexpr const char* kIntrospectionXml =
    "<!DOCTYPE node PUBLIC \"-//freedesktop//DTD D-Bus Object Introspection 1.0//EN\"\n"
    " \"http://www.freedesktop.org/standards/dbus/1.0/introspect.dtd\">\n"
    "<node name=\"/org/vroncevic/${PRO_LOWER}/Object\">\n"
    "  <interface name=\"org.freedesktop.DBus.Introspectable\">\n"
    "    <method name=\"Introspect\">\n"
    "      <arg name=\"xml_data\" type=\"s\" direction=\"out\"/>\n"
    "    </method>\n"
    "  </interface>\n"
    "  <interface name=\"org.freedesktop.DBus.Peer\">\n"
    "    <method name=\"Ping\"/>\n"
    "    <method name=\"GetMachineId\">\n"
    "      <arg name=\"machine_uuid\" type=\"s\" direction=\"out\"/>\n"
    "    </method>\n"
    "  </interface>\n"
    "  <interface name=\"org.freedesktop.DBus.Properties\">\n"
    "    <method name=\"Get\">\n"
    "      <arg name=\"interface_name\" type=\"s\" direction=\"in\"/>\n"
    "      <arg name=\"property_name\" type=\"s\" direction=\"in\"/>\n"
    "      <arg name=\"value\" type=\"v\" direction=\"out\"/>\n"
    "    </method>\n"
    "    <method name=\"Set\">\n"
    "      <arg name=\"interface_name\" type=\"s\" direction=\"in\"/>\n"
    "      <arg name=\"property_name\" type=\"s\" direction=\"in\"/>\n"
    "      <arg name=\"value\" type=\"v\" direction=\"in\"/>\n"
    "    </method>\n"
    "    <method name=\"GetAll\">\n"
    "      <arg name=\"interface_name\" type=\"s\" direction=\"in\"/>\n"
    "      <arg name=\"props\" type=\"a{sv}\" direction=\"out\"/>\n"
    "    </method>\n"
    "    <signal name=\"PropertiesChanged\">\n"
    "      <arg name=\"interface_name\" type=\"s\"/>\n"
    "      <arg name=\"changed_properties\" type=\"a{sv}\"/>\n"
    "      <arg name=\"invalidated_properties\" type=\"as\"/>\n"
    "    </signal>\n"
    "  </interface>\n"
    "  <interface name=\"org.vroncevic.${PRO_LOWER}.Control\">\n"
    "    <method name=\"Ping\">\n"
    "      <arg name=\"message\" type=\"s\" direction=\"in\"/>\n"
    "      <arg name=\"reply\" type=\"s\" direction=\"out\"/>\n"
    "    </method>\n"
    "    <method name=\"SetStatus\">\n"
    "      <arg name=\"new_status\" type=\"s\" direction=\"in\"/>\n"
    "      <arg name=\"applied\" type=\"b\" direction=\"out\"/>\n"
    "    </method>\n"
    "    <property name=\"Status\" type=\"s\" access=\"readwrite\"/>\n"
    "    <property name=\"CallCount\" type=\"u\" access=\"read\"/>\n"
    "    <signal name=\"StatusChanged\">\n"
    "      <arg name=\"old_status\" type=\"s\"/>\n"
    "      <arg name=\"new_status\" type=\"s\"/>\n"
    "    </signal>\n"
    "  </interface>\n"
    "</node>\n";

void append_variant_string(DBusMessageIter* parent, const char* value) {
    DBusMessageIter variant{};
    dbus_message_iter_open_container(parent, DBUS_TYPE_VARIANT, "s", &variant);
    dbus_message_iter_append_basic(&variant, DBUS_TYPE_STRING, &value);
    dbus_message_iter_close_container(parent, &variant);
}

void append_variant_uint32(DBusMessageIter* parent, std::uint32_t value) {
    DBusMessageIter variant{};
    dbus_uint32_t raw = static_cast<dbus_uint32_t>(value);
    dbus_message_iter_open_container(parent, DBUS_TYPE_VARIANT, "u", &variant);
    dbus_message_iter_append_basic(&variant, DBUS_TYPE_UINT32, &raw);
    dbus_message_iter_close_container(parent, &variant);
}

void append_dict_string(DBusMessageIter* dict, const char* key, const char* val) {
    DBusMessageIter entry{};
    dbus_message_iter_open_container(dict, DBUS_TYPE_DICT_ENTRY, nullptr, &entry);
    dbus_message_iter_append_basic(&entry, DBUS_TYPE_STRING, &key);
    append_variant_string(&entry, val);
    dbus_message_iter_close_container(dict, &entry);
}

void append_dict_uint32(DBusMessageIter* dict, const char* key, std::uint32_t val) {
    DBusMessageIter entry{};
    dbus_message_iter_open_container(dict, DBUS_TYPE_DICT_ENTRY, nullptr, &entry);
    dbus_message_iter_append_basic(&entry, DBUS_TYPE_STRING, &key);
    append_variant_uint32(&entry, val);
    dbus_message_iter_close_container(dict, &entry);
}

void send_error_reply(DBusConnection* conn, DBusMessage* msg, const char* err_name, const char* text) {
    UniqueMessage reply{dbus_message_new_error(msg, err_name, text)};
    if (reply) {
        dbus_connection_send(conn, reply.get(), nullptr);
        dbus_connection_flush(conn);
    }
}

} // namespace

${PRO_PASCAL}Server::${PRO_PASCAL}Server() {
    DBusErrorGuard err;
    conn_.reset(dbus_bus_get(${C_BUS_CONST}, err.get()));
    err.throw_if_set("dbus_bus_get");
    if (!conn_) {
        throw std::runtime_error("Failed to acquire D-Bus connection");
    }

    const int name_rc = dbus_bus_request_name(
        conn_.get(),
        kBusName.data(),
        DBUS_NAME_FLAG_REPLACE_EXISTING | DBUS_NAME_FLAG_DO_NOT_QUEUE,
        err.get()
    );
    err.throw_if_set("dbus_bus_request_name");
    if (name_rc != DBUS_REQUEST_NAME_REPLY_PRIMARY_OWNER) {
        throw std::runtime_error("Could not become primary owner of bus name");
    }

    DBusObjectPathVTable vtable{};
    vtable.message_function = &${PRO_PASCAL}Server::vtable_dispatch;

    if (!dbus_connection_try_register_object_path(
            conn_.get(), kObjectPath.data(), &vtable, this, err.get())) {
        err.throw_if_set("dbus_connection_try_register_object_path");
        throw std::runtime_error("Failed to register D-Bus object path");
    }
}

${PRO_PASCAL}Server::~${PRO_PASCAL}Server() {
    if (conn_) {
        dbus_connection_unregister_object_path(conn_.get(), kObjectPath.data());
        DBusErrorGuard err;
        dbus_bus_release_name(conn_.get(), kBusName.data(), err.get());
    }
}

void ${PRO_PASCAL}Server::stop() noexcept {
    running_.store(false);
}

void ${PRO_PASCAL}Server::run(bool once_mode) {
    std::cout << "[server] Ready on " << kBusName << " (" << kObjectPath << ")\n";
    while (running_.load()) {
        if (!dbus_connection_read_write_dispatch(conn_.get(), 200)) {
            break;
        }
        if (once_mode && control_ops_ >= 3U) {
            dbus_connection_read_write_dispatch(conn_.get(), 100);
            break;
        }
    }
}

DBusHandlerResult ${PRO_PASCAL}Server::vtable_dispatch(
    DBusConnection* /*conn*/,
    DBusMessage* msg,
    void* user_data
) noexcept {
    auto* self = static_cast<${PRO_PASCAL}Server*>(user_data);
    try {
        return self->handle_message(msg);
    } catch (const std::exception& ex) {
        std::cerr << "[server] Handler exception: " << ex.what() << "\n";
        return DBUS_HANDLER_RESULT_NOT_YET_HANDLED;
    }
}

DBusHandlerResult ${PRO_PASCAL}Server::handle_message(DBusMessage* msg) {
    const char* iface = dbus_message_get_interface(msg);
    if (iface == nullptr) {
        return DBUS_HANDLER_RESULT_NOT_YET_HANDLED;
    }
    const std::string_view iface_sv{iface};
    if (iface_sv == DBUS_INTERFACE_INTROSPECTABLE) {
        return handle_introspect(msg);
    }
    if (iface_sv == DBUS_INTERFACE_PEER) {
        return handle_peer(msg);
    }
    if (iface_sv == DBUS_INTERFACE_PROPERTIES) {
        return handle_properties(msg);
    }
    if (iface_sv == kInterfaceName) {
        return handle_control(msg);
    }
    return DBUS_HANDLER_RESULT_NOT_YET_HANDLED;
}

DBusHandlerResult ${PRO_PASCAL}Server::handle_introspect(DBusMessage* msg) {
    if (!dbus_message_is_method_call(msg, DBUS_INTERFACE_INTROSPECTABLE, "Introspect")) {
        return DBUS_HANDLER_RESULT_NOT_YET_HANDLED;
    }
    UniqueMessage reply{dbus_message_new_method_return(msg)};
    const char* xml = kIntrospectionXml;
    dbus_message_append_args(reply.get(), DBUS_TYPE_STRING, &xml, DBUS_TYPE_INVALID);
    dbus_connection_send(conn_.get(), reply.get(), nullptr);
    dbus_connection_flush(conn_.get());
    return DBUS_HANDLER_RESULT_HANDLED;
}

DBusHandlerResult ${PRO_PASCAL}Server::handle_peer(DBusMessage* msg) {
    if (dbus_message_is_method_call(msg, DBUS_INTERFACE_PEER, "Ping")) {
        UniqueMessage reply{dbus_message_new_method_return(msg)};
        dbus_connection_send(conn_.get(), reply.get(), nullptr);
        dbus_connection_flush(conn_.get());
        return DBUS_HANDLER_RESULT_HANDLED;
    }
    if (dbus_message_is_method_call(msg, DBUS_INTERFACE_PEER, "GetMachineId")) {
        char* machine_id = dbus_get_local_machine_id();
        UniqueMessage reply{dbus_message_new_method_return(msg)};
        const char* id_str = (machine_id != nullptr) ? machine_id : "unknown";
        dbus_message_append_args(reply.get(), DBUS_TYPE_STRING, &id_str, DBUS_TYPE_INVALID);
        dbus_connection_send(conn_.get(), reply.get(), nullptr);
        dbus_connection_flush(conn_.get());
        if (machine_id != nullptr) {
            dbus_free(machine_id);
        }
        return DBUS_HANDLER_RESULT_HANDLED;
    }
    return DBUS_HANDLER_RESULT_NOT_YET_HANDLED;
}

DBusHandlerResult ${PRO_PASCAL}Server::handle_properties(DBusMessage* msg) {
    if (dbus_message_is_method_call(msg, DBUS_INTERFACE_PROPERTIES, "Get")) {
        DBusErrorGuard err;
        const char* iface = nullptr;
        const char* prop = nullptr;
        if (!dbus_message_get_args(
                msg, err.get(), DBUS_TYPE_STRING, &iface, DBUS_TYPE_STRING, &prop, DBUS_TYPE_INVALID)) {
            send_error_reply(conn_.get(), msg, DBUS_ERROR_INVALID_ARGS, "Expected (ss)");
            return DBUS_HANDLER_RESULT_HANDLED;
        }
        if (std::string_view{iface} != kInterfaceName) {
            send_error_reply(conn_.get(), msg, DBUS_ERROR_UNKNOWN_INTERFACE, iface);
            return DBUS_HANDLER_RESULT_HANDLED;
        }
        UniqueMessage reply{dbus_message_new_method_return(msg)};
        DBusMessageIter root{};
        dbus_message_iter_init_append(reply.get(), &root);
        const std::string_view prop_sv{prop};
        if (prop_sv == "Status") {
            append_variant_string(&root, status_.c_str());
        } else if (prop_sv == "CallCount") {
            append_variant_uint32(&root, call_count_);
        } else {
            send_error_reply(conn_.get(), msg, DBUS_ERROR_UNKNOWN_PROPERTY, prop);
            return DBUS_HANDLER_RESULT_HANDLED;
        }
        dbus_connection_send(conn_.get(), reply.get(), nullptr);
        dbus_connection_flush(conn_.get());
        return DBUS_HANDLER_RESULT_HANDLED;
    }

    if (dbus_message_is_method_call(msg, DBUS_INTERFACE_PROPERTIES, "Set")) {
        DBusMessageIter iter{};
        if (!dbus_message_iter_init(msg, &iter) ||
            dbus_message_iter_get_arg_type(&iter) != DBUS_TYPE_STRING) {
            send_error_reply(conn_.get(), msg, DBUS_ERROR_INVALID_ARGS, "Expected interface string");
            return DBUS_HANDLER_RESULT_HANDLED;
        }
        const char* iface = nullptr;
        dbus_message_iter_get_basic(&iter, &iface);
        if (!dbus_message_iter_next(&iter) ||
            dbus_message_iter_get_arg_type(&iter) != DBUS_TYPE_STRING) {
            send_error_reply(conn_.get(), msg, DBUS_ERROR_INVALID_ARGS, "Expected property string");
            return DBUS_HANDLER_RESULT_HANDLED;
        }
        const char* prop = nullptr;
        dbus_message_iter_get_basic(&iter, &prop);
        if (!dbus_message_iter_next(&iter) ||
            dbus_message_iter_get_arg_type(&iter) != DBUS_TYPE_VARIANT) {
            send_error_reply(conn_.get(), msg, DBUS_ERROR_INVALID_ARGS, "Expected variant value");
            return DBUS_HANDLER_RESULT_HANDLED;
        }
        if (std::string_view{iface} != kInterfaceName) {
            send_error_reply(conn_.get(), msg, DBUS_ERROR_UNKNOWN_INTERFACE, iface);
            return DBUS_HANDLER_RESULT_HANDLED;
        }
        const std::string_view prop_sv{prop};
        if (prop_sv == "CallCount") {
            send_error_reply(conn_.get(), msg, DBUS_ERROR_PROPERTY_READ_ONLY, "CallCount is read-only");
            return DBUS_HANDLER_RESULT_HANDLED;
        }
        if (prop_sv != "Status") {
            send_error_reply(conn_.get(), msg, DBUS_ERROR_UNKNOWN_PROPERTY, prop);
            return DBUS_HANDLER_RESULT_HANDLED;
        }
        DBusMessageIter variant{};
        dbus_message_iter_recurse(&iter, &variant);
        if (dbus_message_iter_get_arg_type(&variant) != DBUS_TYPE_STRING) {
            send_error_reply(conn_.get(), msg, DBUS_ERROR_INVALID_ARGS, "Status expects string");
            return DBUS_HANDLER_RESULT_HANDLED;
        }
        const char* next_val = nullptr;
        dbus_message_iter_get_basic(&variant, &next_val);
        ++call_count_;
        ++control_ops_;
        apply_status_change(next_val != nullptr ? next_val : "");

        UniqueMessage reply{dbus_message_new_method_return(msg)};
        dbus_connection_send(conn_.get(), reply.get(), nullptr);
        dbus_connection_flush(conn_.get());
        return DBUS_HANDLER_RESULT_HANDLED;
    }

    if (dbus_message_is_method_call(msg, DBUS_INTERFACE_PROPERTIES, "GetAll")) {
        DBusErrorGuard err;
        const char* iface = nullptr;
        if (!dbus_message_get_args(msg, err.get(), DBUS_TYPE_STRING, &iface, DBUS_TYPE_INVALID)) {
            send_error_reply(conn_.get(), msg, DBUS_ERROR_INVALID_ARGS, "Expected (s)");
            return DBUS_HANDLER_RESULT_HANDLED;
        }
        UniqueMessage reply{dbus_message_new_method_return(msg)};
        DBusMessageIter root{};
        DBusMessageIter dict{};
        dbus_message_iter_init_append(reply.get(), &root);
        dbus_message_iter_open_container(&root, DBUS_TYPE_ARRAY, "{sv}", &dict);
        if (std::string_view{iface}.empty() || std::string_view{iface} == kInterfaceName) {
            append_dict_string(&dict, "Status", status_.c_str());
            append_dict_uint32(&dict, "CallCount", call_count_);
        }
        dbus_message_iter_close_container(&root, &dict);
        dbus_connection_send(conn_.get(), reply.get(), nullptr);
        dbus_connection_flush(conn_.get());
        return DBUS_HANDLER_RESULT_HANDLED;
    }

    return DBUS_HANDLER_RESULT_NOT_YET_HANDLED;
}

DBusHandlerResult ${PRO_PASCAL}Server::handle_control(DBusMessage* msg) {
    if (dbus_message_is_method_call(msg, kInterfaceName.data(), "Ping")) {
        DBusErrorGuard err;
        const char* payload = nullptr;
        if (!dbus_message_get_args(msg, err.get(), DBUS_TYPE_STRING, &payload, DBUS_TYPE_INVALID)) {
            send_error_reply(conn_.get(), msg, DBUS_ERROR_INVALID_ARGS, "Expected (s)");
            return DBUS_HANDLER_RESULT_HANDLED;
        }
        ++call_count_;
        ++control_ops_;
        emit_properties_changed();
        const std::string formatted = std::string{"[${PRO}] pong: "} + (payload != nullptr ? payload : "");
        const char* out_ptr = formatted.c_str();
        UniqueMessage reply{dbus_message_new_method_return(msg)};
        dbus_message_append_args(reply.get(), DBUS_TYPE_STRING, &out_ptr, DBUS_TYPE_INVALID);
        dbus_connection_send(conn_.get(), reply.get(), nullptr);
        dbus_connection_flush(conn_.get());
        return DBUS_HANDLER_RESULT_HANDLED;
    }

    if (dbus_message_is_method_call(msg, kInterfaceName.data(), "SetStatus")) {
        DBusErrorGuard err;
        const char* next_status = nullptr;
        if (!dbus_message_get_args(msg, err.get(), DBUS_TYPE_STRING, &next_status, DBUS_TYPE_INVALID)) {
            send_error_reply(conn_.get(), msg, DBUS_ERROR_INVALID_ARGS, "Expected (s)");
            return DBUS_HANDLER_RESULT_HANDLED;
        }
        ++call_count_;
        ++control_ops_;
        apply_status_change(next_status != nullptr ? next_status : "");
        dbus_bool_t applied = TRUE;
        UniqueMessage reply{dbus_message_new_method_return(msg)};
        dbus_message_append_args(reply.get(), DBUS_TYPE_BOOLEAN, &applied, DBUS_TYPE_INVALID);
        dbus_connection_send(conn_.get(), reply.get(), nullptr);
        dbus_connection_flush(conn_.get());
        return DBUS_HANDLER_RESULT_HANDLED;
    }

    return DBUS_HANDLER_RESULT_NOT_YET_HANDLED;
}

void ${PRO_PASCAL}Server::apply_status_change(const std::string& next_status) {
    const std::string previous = status_;
    status_ = next_status;
    emit_status_changed(previous, status_);
    emit_properties_changed();
}

void ${PRO_PASCAL}Server::emit_status_changed(
    const std::string& old_status,
    const std::string& new_status
) {
    UniqueMessage sig{dbus_message_new_signal(
        kObjectPath.data(), kInterfaceName.data(), "StatusChanged"
    )};
    if (!sig) {
        return;
    }
    const char* old_ptr = old_status.c_str();
    const char* new_ptr = new_status.c_str();
    dbus_message_append_args(
        sig.get(),
        DBUS_TYPE_STRING, &old_ptr,
        DBUS_TYPE_STRING, &new_ptr,
        DBUS_TYPE_INVALID
    );
    dbus_connection_send(conn_.get(), sig.get(), nullptr);
    dbus_connection_flush(conn_.get());
}

void ${PRO_PASCAL}Server::emit_properties_changed() {
    UniqueMessage sig{dbus_message_new_signal(
        kObjectPath.data(), DBUS_INTERFACE_PROPERTIES, "PropertiesChanged"
    )};
    if (!sig) {
        return;
    }
    DBusMessageIter root{};
    DBusMessageIter changed{};
    DBusMessageIter invalidated{};
    const char* iface_ptr = kInterfaceName.data();
    dbus_message_iter_init_append(sig.get(), &root);
    dbus_message_iter_append_basic(&root, DBUS_TYPE_STRING, &iface_ptr);
    dbus_message_iter_open_container(&root, DBUS_TYPE_ARRAY, "{sv}", &changed);
    append_dict_string(&changed, "Status", status_.c_str());
    append_dict_uint32(&changed, "CallCount", call_count_);
    dbus_message_iter_close_container(&root, &changed);
    dbus_message_iter_open_container(&root, DBUS_TYPE_ARRAY, "s", &invalidated);
    dbus_message_iter_close_container(&root, &invalidated);
    dbus_connection_send(conn_.get(), sig.get(), nullptr);
    dbus_connection_flush(conn_.get());
}

} // namespace ${PRO_LOWER}::dbus
