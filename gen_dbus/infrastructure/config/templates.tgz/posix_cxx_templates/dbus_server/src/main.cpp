/*
 * main.cpp
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 * Distributed under terms of the GNU General Public License v3.0.
 */
#include "dbus_server.hpp"
#include <csignal>
#include <cstdlib>
#include <iostream>
#include <string_view>

namespace {

${PRO_LOWER}::dbus::${PRO_PASCAL}Server* g_server_instance = nullptr;

void signal_handler(int /*signum*/) {
    if (g_server_instance != nullptr) {
        g_server_instance->stop();
    }
}

} // namespace

int main(int argc, char* argv[]) {
    bool once_mode = false;
    for (int idx = 1; idx < argc; ++idx) {
        if (std::string_view{argv[idx]} == "--once") {
            once_mode = true;
        }
    }

    try {
        ${PRO_LOWER}::dbus::${PRO_PASCAL}Server server;
        g_server_instance = &server;
        std::signal(SIGINT, signal_handler);
        std::signal(SIGTERM, signal_handler);
        server.run(once_mode);
        g_server_instance = nullptr;
        return EXIT_SUCCESS;
    } catch (const std::exception& ex) {
        std::cerr << "[server] Fatal error: " << ex.what() << "\n";
        return EXIT_FAILURE;
    }
}
