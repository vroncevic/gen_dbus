add_executable(${PRO_LOWER}_server
    src/dbus_server.cpp
    src/main.cpp
)

target_include_directories(${PRO_LOWER}_server PRIVATE
    "$${CMAKE_CURRENT_SOURCE_DIR}/include"
)

target_compile_options(${PRO_LOWER}_server PRIVATE -Wall -Wextra -Wpedantic)
target_link_libraries(${PRO_LOWER}_server PRIVATE PkgConfig::DBUS)
