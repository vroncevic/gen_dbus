/*
 * dbus_server.hpp
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 * Distributed under terms of the GNU General Public License v3.0.
 */
#pragma once

#include "dbus_raii.hpp"
#include <atomic>
#include <cstdint>
#include <string>
#include <string_view>

namespace ${PRO_LOWER}::dbus {

class ${PRO_PASCAL}Server final {
public:
    static constexpr std::string_view kBusName = "org.vroncevic.${PRO_LOWER}.Service";
    static constexpr std::string_view kObjectPath = "/org/vroncevic/${PRO_LOWER}/Object";
    static constexpr std::string_view kInterfaceName = "org.vroncevic.${PRO_LOWER}.Control";

    ${PRO_PASCAL}Server();
    ~${PRO_PASCAL}Server();

    ${PRO_PASCAL}Server(const ${PRO_PASCAL}Server&) = delete;
    ${PRO_PASCAL}Server& operator=(const ${PRO_PASCAL}Server&) = delete;

    void run(bool once_mode);
    void stop() noexcept;

private:
    static DBusHandlerResult vtable_dispatch(
        DBusConnection* conn,
        DBusMessage* msg,
        void* user_data
    ) noexcept;

    DBusHandlerResult handle_message(DBusMessage* msg);
    DBusHandlerResult handle_introspect(DBusMessage* msg);
    DBusHandlerResult handle_peer(DBusMessage* msg);
    DBusHandlerResult handle_properties(DBusMessage* msg);
    DBusHandlerResult handle_control(DBusMessage* msg);

    void apply_status_change(const std::string& next_status);
    void emit_status_changed(const std::string& old_status, const std::string& new_status);
    void emit_properties_changed();

    UniqueConnection conn_{};
    std::string status_{"idle"};
    std::uint32_t call_count_{0U};
    std::uint32_t control_ops_{0U};
    std::atomic<bool> running_{true};
};

} // namespace ${PRO_LOWER}::dbus
