cmake_minimum_required(VERSION 3.16)
project(${PRO} VERSION 1.0.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

find_package(PkgConfig REQUIRED)
pkg_check_modules(DBUS REQUIRED IMPORTED_TARGET dbus-1)

if(EXISTS "$${CMAKE_CURRENT_SOURCE_DIR}/dbus_server/CMakeLists.txt")
    add_subdirectory(dbus_server)
endif()

if(EXISTS "$${CMAKE_CURRENT_SOURCE_DIR}/dbus_client/CMakeLists.txt")
    add_subdirectory(dbus_client)
endif()
