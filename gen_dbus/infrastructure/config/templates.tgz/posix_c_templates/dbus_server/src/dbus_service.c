/* -*- Mode: C; indent-tabs-mode: nil; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * dbus_service.c
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 */

#include "dbus_service.h"
#include "dbus_config.h"

#include <stdio.h>
#include <string.h>

static bool append_variant_string(DBusMessageIter *iter, const char *value) {
    DBusMessageIter variant;
    if (!dbus_message_iter_open_container(iter, DBUS_TYPE_VARIANT, "s", &variant)) {
        return false;
    }
    if (!dbus_message_iter_append_basic(&variant, DBUS_TYPE_STRING, &value)) {
        dbus_message_iter_abandon_container(iter, &variant);
        return false;
    }
    return dbus_message_iter_close_container(iter, &variant) != FALSE;
}

static bool append_variant_uint32(DBusMessageIter *iter, dbus_uint32_t value) {
    DBusMessageIter variant;
    if (!dbus_message_iter_open_container(iter, DBUS_TYPE_VARIANT, "u", &variant)) {
        return false;
    }
    if (!dbus_message_iter_append_basic(&variant, DBUS_TYPE_UINT32, &value)) {
        dbus_message_iter_abandon_container(iter, &variant);
        return false;
    }
    return dbus_message_iter_close_container(iter, &variant) != FALSE;
}

static bool append_dict_entry_string(
    DBusMessageIter *dict,
    const char *key,
    const char *value
) {
    DBusMessageIter entry;
    if (!dbus_message_iter_open_container(dict, DBUS_TYPE_DICT_ENTRY, NULL, &entry)) {
        return false;
    }
    if (!dbus_message_iter_append_basic(&entry, DBUS_TYPE_STRING, &key) ||
        !append_variant_string(&entry, value)) {
        dbus_message_iter_abandon_container(dict, &entry);
        return false;
    }
    return dbus_message_iter_close_container(dict, &entry) != FALSE;
}

static bool append_dict_entry_uint32(
    DBusMessageIter *dict,
    const char *key,
    dbus_uint32_t value
) {
    DBusMessageIter entry;
    if (!dbus_message_iter_open_container(dict, DBUS_TYPE_DICT_ENTRY, NULL, &entry)) {
        return false;
    }
    if (!dbus_message_iter_append_basic(&entry, DBUS_TYPE_STRING, &key) ||
        !append_variant_uint32(&entry, value)) {
        dbus_message_iter_abandon_container(dict, &entry);
        return false;
    }
    return dbus_message_iter_close_container(dict, &entry) != FALSE;
}

static void emit_properties_changed(
    DBusConnection *connection,
    const char *new_status
) {
    DBusMessage *sig = dbus_message_new_signal(
        SERVICE_OBJECT_PATH,
        DBUS_INTERFACE_PROPERTIES,
        "PropertiesChanged"
    );
    if (sig == NULL) {
        return;
    }

    DBusMessageIter iter;
    DBusMessageIter changed_dict;
    DBusMessageIter invalidated_arr;
    const char *iface = SERVICE_INTERFACE;

    dbus_message_iter_init_append(sig, &iter);
    if (dbus_message_iter_append_basic(&iter, DBUS_TYPE_STRING, &iface) &&
        dbus_message_iter_open_container(&iter, DBUS_TYPE_ARRAY, "{sv}", &changed_dict) &&
        append_dict_entry_string(&changed_dict, "Status", new_status) &&
        dbus_message_iter_close_container(&iter, &changed_dict) &&
        dbus_message_iter_open_container(&iter, DBUS_TYPE_ARRAY, "s", &invalidated_arr) &&
        dbus_message_iter_close_container(&iter, &invalidated_arr)) {
        dbus_connection_send(connection, sig, NULL);
        dbus_connection_flush(connection);
    }
    dbus_message_unref(sig);
}

void service_state_init(ServiceState *state, bool stop_after_set_status) {
    if (state == NULL) {
        return;
    }
    snprintf(state->status, sizeof(state->status), "%s", "IDLE");
    state->call_count = 0U;
    state->stop_after_set_status = stop_after_set_status;
    state->should_stop = false;
}

bool service_emit_status_changed(
    DBusConnection *connection,
    const char *old_status,
    const char *new_status
) {
    DBusMessage *signal_msg = dbus_message_new_signal(
        SERVICE_OBJECT_PATH,
        SERVICE_INTERFACE,
        "StatusChanged"
    );
    if (signal_msg == NULL) {
        return false;
    }

    bool ok = dbus_message_append_args(
        signal_msg,
        DBUS_TYPE_STRING, &old_status,
        DBUS_TYPE_STRING, &new_status,
        DBUS_TYPE_INVALID
    ) != FALSE;

    if (ok) {
        ok = dbus_connection_send(connection, signal_msg, NULL) != FALSE;
        dbus_connection_flush(connection);
    }
    dbus_message_unref(signal_msg);
    return ok;
}

static DBusHandlerResult handle_introspect(
    DBusConnection *connection,
    DBusMessage *message
) {
    DBusMessage *reply = dbus_message_new_method_return(message);
    if (reply == NULL) {
        return DBUS_HANDLER_RESULT_NEED_MEMORY;
    }
    const char *xml = SERVICE_INTROSPECT_XML;
    dbus_message_append_args(reply, DBUS_TYPE_STRING, &xml, DBUS_TYPE_INVALID);
    dbus_connection_send(connection, reply, NULL);
    dbus_message_unref(reply);
    return DBUS_HANDLER_RESULT_HANDLED;
}

static DBusHandlerResult handle_properties_get(
    DBusConnection *connection,
    DBusMessage *message,
    ServiceState *state
) {
    DBusError err;
    dbus_error_init(&err);
    const char *iface = NULL;
    const char *prop = NULL;

    if (!dbus_message_get_args(
            message, &err,
            DBUS_TYPE_STRING, &iface,
            DBUS_TYPE_STRING, &prop,
            DBUS_TYPE_INVALID)) {
        DBusMessage *err_reply = dbus_message_new_error(message, err.name, err.message);
        dbus_error_free(&err);
        if (err_reply != NULL) {
            dbus_connection_send(connection, err_reply, NULL);
            dbus_message_unref(err_reply);
        }
        return DBUS_HANDLER_RESULT_HANDLED;
    }

    if (strcmp(iface, SERVICE_INTERFACE) != 0 && iface[0] != '\0') {
        DBusMessage *err_reply = dbus_message_new_error(
            message, DBUS_ERROR_UNKNOWN_INTERFACE, "Unknown interface"
        );
        if (err_reply != NULL) {
            dbus_connection_send(connection, err_reply, NULL);
            dbus_message_unref(err_reply);
        }
        return DBUS_HANDLER_RESULT_HANDLED;
    }

    DBusMessage *reply = dbus_message_new_method_return(message);
    if (reply == NULL) {
        return DBUS_HANDLER_RESULT_NEED_MEMORY;
    }

    DBusMessageIter iter;
    dbus_message_iter_init_append(reply, &iter);

    if (strcmp(prop, "Status") == 0) {
        append_variant_string(&iter, state->status);
    } else if (strcmp(prop, "CallCount") == 0) {
        append_variant_uint32(&iter, (dbus_uint32_t)state->call_count);
    } else {
        dbus_message_unref(reply);
        DBusMessage *err_reply = dbus_message_new_error(
            message, DBUS_ERROR_UNKNOWN_PROPERTY, "Unknown property"
        );
        if (err_reply != NULL) {
            dbus_connection_send(connection, err_reply, NULL);
            dbus_message_unref(err_reply);
        }
        return DBUS_HANDLER_RESULT_HANDLED;
    }

    dbus_connection_send(connection, reply, NULL);
    dbus_message_unref(reply);
    return DBUS_HANDLER_RESULT_HANDLED;
}

static DBusHandlerResult handle_properties_set(
    DBusConnection *connection,
    DBusMessage *message,
    ServiceState *state
) {
    DBusMessageIter iter;
    if (!dbus_message_iter_init(message, &iter)) {
        return DBUS_HANDLER_RESULT_NOT_YET_HANDLED;
    }

    const char *iface = NULL;
    const char *prop = NULL;
    if (dbus_message_iter_get_arg_type(&iter) != DBUS_TYPE_STRING) {
        return DBUS_HANDLER_RESULT_NOT_YET_HANDLED;
    }
    dbus_message_iter_get_basic(&iter, &iface);
    dbus_message_iter_next(&iter);

    if (dbus_message_iter_get_arg_type(&iter) != DBUS_TYPE_STRING) {
        return DBUS_HANDLER_RESULT_NOT_YET_HANDLED;
    }
    dbus_message_iter_get_basic(&iter, &prop);
    dbus_message_iter_next(&iter);

    if (strcmp(prop, "Status") != 0 ||
        dbus_message_iter_get_arg_type(&iter) != DBUS_TYPE_VARIANT) {
        DBusMessage *err_reply = dbus_message_new_error(
            message, DBUS_ERROR_PROPERTY_READ_ONLY, "Property cannot be modified"
        );
        if (err_reply != NULL) {
            dbus_connection_send(connection, err_reply, NULL);
            dbus_message_unref(err_reply);
        }
        return DBUS_HANDLER_RESULT_HANDLED;
    }

    DBusMessageIter variant;
    dbus_message_iter_recurse(&iter, &variant);
    if (dbus_message_iter_get_arg_type(&variant) != DBUS_TYPE_STRING) {
        DBusMessage *err_reply = dbus_message_new_error(
            message, DBUS_ERROR_INVALID_ARGS, "Status expects string"
        );
        if (err_reply != NULL) {
            dbus_connection_send(connection, err_reply, NULL);
            dbus_message_unref(err_reply);
        }
        return DBUS_HANDLER_RESULT_HANDLED;
    }

    const char *new_val = NULL;
    dbus_message_iter_get_basic(&variant, &new_val);

    char old_status[SERVICE_STATUS_MAX_LEN];
    snprintf(old_status, sizeof(old_status), "%s", state->status);
    snprintf(state->status, sizeof(state->status), "%s", new_val);

    DBusMessage *reply = dbus_message_new_method_return(message);
    if (reply != NULL) {
        dbus_connection_send(connection, reply, NULL);
        dbus_message_unref(reply);
    }

    service_emit_status_changed(connection, old_status, state->status);
    emit_properties_changed(connection, state->status);
    return DBUS_HANDLER_RESULT_HANDLED;
}

static DBusHandlerResult handle_properties_get_all(
    DBusConnection *connection,
    DBusMessage *message,
    ServiceState *state
) {
    DBusMessage *reply = dbus_message_new_method_return(message);
    if (reply == NULL) {
        return DBUS_HANDLER_RESULT_NEED_MEMORY;
    }

    DBusMessageIter iter;
    DBusMessageIter dict;
    dbus_message_iter_init_append(reply, &iter);

    if (dbus_message_iter_open_container(&iter, DBUS_TYPE_ARRAY, "{sv}", &dict)) {
        append_dict_entry_string(&dict, "Status", state->status);
        append_dict_entry_uint32(&dict, "CallCount", (dbus_uint32_t)state->call_count);
        dbus_message_iter_close_container(&iter, &dict);
    }

    dbus_connection_send(connection, reply, NULL);
    dbus_message_unref(reply);
    return DBUS_HANDLER_RESULT_HANDLED;
}

static DBusHandlerResult handle_ping(
    DBusConnection *connection,
    DBusMessage *message,
    ServiceState *state
) {
    DBusError err;
    dbus_error_init(&err);
    const char *payload = NULL;

    if (!dbus_message_get_args(
            message, &err, DBUS_TYPE_STRING, &payload, DBUS_TYPE_INVALID)) {
        DBusMessage *err_reply = dbus_message_new_error(message, err.name, err.message);
        dbus_error_free(&err);
        if (err_reply != NULL) {
            dbus_connection_send(connection, err_reply, NULL);
            dbus_message_unref(err_reply);
        }
        return DBUS_HANDLER_RESULT_HANDLED;
    }

    state->call_count += 1U;
    char response_buf[256];
    snprintf(
        response_buf,
        sizeof(response_buf),
        "Pong from ${PRO} [call=#%u, status=%s]: %s",
        state->call_count,
        state->status,
        payload
    );

    DBusMessage *reply = dbus_message_new_method_return(message);
    if (reply == NULL) {
        return DBUS_HANDLER_RESULT_NEED_MEMORY;
    }
    const char *resp_ptr = response_buf;
    dbus_message_append_args(reply, DBUS_TYPE_STRING, &resp_ptr, DBUS_TYPE_INVALID);
    dbus_connection_send(connection, reply, NULL);
    dbus_message_unref(reply);
    return DBUS_HANDLER_RESULT_HANDLED;
}

static DBusHandlerResult handle_set_status(
    DBusConnection *connection,
    DBusMessage *message,
    ServiceState *state
) {
    DBusError err;
    dbus_error_init(&err);
    const char *new_status = NULL;

    if (!dbus_message_get_args(
            message, &err, DBUS_TYPE_STRING, &new_status, DBUS_TYPE_INVALID)) {
        DBusMessage *err_reply = dbus_message_new_error(message, err.name, err.message);
        dbus_error_free(&err);
        if (err_reply != NULL) {
            dbus_connection_send(connection, err_reply, NULL);
            dbus_message_unref(err_reply);
        }
        return DBUS_HANDLER_RESULT_HANDLED;
    }

    state->call_count += 1U;
    char old_status[SERVICE_STATUS_MAX_LEN];
    snprintf(old_status, sizeof(old_status), "%s", state->status);
    snprintf(state->status, sizeof(state->status), "%s", new_status);

    dbus_bool_t applied = TRUE;
    DBusMessage *reply = dbus_message_new_method_return(message);
    if (reply == NULL) {
        return DBUS_HANDLER_RESULT_NEED_MEMORY;
    }
    dbus_message_append_args(reply, DBUS_TYPE_BOOLEAN, &applied, DBUS_TYPE_INVALID);
    dbus_connection_send(connection, reply, NULL);
    dbus_connection_flush(connection);
    dbus_message_unref(reply);

    service_emit_status_changed(connection, old_status, state->status);
    emit_properties_changed(connection, state->status);

    if (state->stop_after_set_status) {
        state->should_stop = true;
    }
    return DBUS_HANDLER_RESULT_HANDLED;
}

DBusHandlerResult service_message_handler(
    DBusConnection *connection,
    DBusMessage *message,
    void *user_data
) {
    ServiceState *state = (ServiceState *)user_data;

    if (dbus_message_is_method_call(
            message, DBUS_INTERFACE_INTROSPECTABLE, "Introspect")) {
        return handle_introspect(connection, message);
    }
    if (dbus_message_is_method_call(message, DBUS_INTERFACE_PEER, "Ping")) {
        DBusMessage *reply = dbus_message_new_method_return(message);
        if (reply != NULL) {
            dbus_connection_send(connection, reply, NULL);
            dbus_message_unref(reply);
        }
        return DBUS_HANDLER_RESULT_HANDLED;
    }
    if (dbus_message_is_method_call(message, DBUS_INTERFACE_PROPERTIES, "Get")) {
        return handle_properties_get(connection, message, state);
    }
    if (dbus_message_is_method_call(message, DBUS_INTERFACE_PROPERTIES, "Set")) {
        return handle_properties_set(connection, message, state);
    }
    if (dbus_message_is_method_call(message, DBUS_INTERFACE_PROPERTIES, "GetAll")) {
        return handle_properties_get_all(connection, message, state);
    }
    if (dbus_message_is_method_call(message, SERVICE_INTERFACE, "Ping")) {
        return handle_ping(connection, message, state);
    }
    if (dbus_message_is_method_call(message, SERVICE_INTERFACE, "SetStatus")) {
        return handle_set_status(connection, message, state);
    }

    return DBUS_HANDLER_RESULT_NOT_YET_HANDLED;
}
