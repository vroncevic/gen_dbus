/* -*- Mode: C; indent-tabs-mode: nil; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * main.c
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 */

#include "dbus_config.h"
#include "dbus_service.h"

#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static volatile sig_atomic_t g_running = 1;

static void handle_signal(int signum) {
    (void)signum;
    g_running = 0;
}

int main(int argc, char *argv[]) {
    bool stop_after_set_status = false;
    for (int i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "--once") == 0) {
            stop_after_set_status = true;
        }
    }

    signal(SIGINT, handle_signal);
    signal(SIGTERM, handle_signal);

    DBusError err;
    dbus_error_init(&err);

    DBusConnection *conn = dbus_bus_get(SERVICE_BUS_TYPE, &err);
    if (dbus_error_is_set(&err) || conn == NULL) {
        fprintf(stderr, "[server] D-Bus connection error: %s\n", err.message);
        dbus_error_free(&err);
        return EXIT_FAILURE;
    }

    int ret = dbus_bus_request_name(
        conn, SERVICE_BUS_NAME, DBUS_NAME_FLAG_REPLACE_EXISTING, &err
    );
    if (dbus_error_is_set(&err) || ret != DBUS_REQUEST_NAME_REPLY_PRIMARY_OWNER) {
        fprintf(
            stderr,
            "[server] Failed to acquire bus name '%s': %s\n",
            SERVICE_BUS_NAME,
            dbus_error_is_set(&err) ? err.message : "not primary owner"
        );
        dbus_error_free(&err);
        dbus_connection_unref(conn);
        return EXIT_FAILURE;
    }

    ServiceState state;
    service_state_init(&state, stop_after_set_status);

    DBusObjectPathVTable vtable = {0};
    vtable.message_function = service_message_handler;

    if (!dbus_connection_register_object_path(
            conn, SERVICE_OBJECT_PATH, &vtable, &state)) {
        fprintf(stderr, "[server] Failed to register object path\n");
        dbus_connection_unref(conn);
        return EXIT_FAILURE;
    }

    printf(
        "[server] ${PRO} listening on %s (%s)\n",
        SERVICE_BUS_NAME,
        SERVICE_OBJECT_PATH
    );
    fflush(stdout);

    while (g_running && !state.should_stop) {
        if (!dbus_connection_read_write_dispatch(conn, 200)) {
            break;
        }
    }

    dbus_connection_unregister_object_path(conn, SERVICE_OBJECT_PATH);
    dbus_bus_release_name(conn, SERVICE_BUS_NAME, NULL);
    dbus_connection_unref(conn);
    printf("[server] Shutdown complete.\n");
    return EXIT_SUCCESS;
}
