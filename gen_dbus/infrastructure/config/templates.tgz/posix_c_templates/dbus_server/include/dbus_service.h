/* -*- Mode: C; indent-tabs-mode: nil; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * dbus_service.h
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 */

#ifndef ${PRO_UPPER}_SERVER_DBUS_SERVICE_H
#define ${PRO_UPPER}_SERVER_DBUS_SERVICE_H

#include <dbus/dbus.h>
#include <stdbool.h>
#include <stdint.h>

enum { SERVICE_STATUS_MAX_LEN = 128 };

typedef struct ServiceState {
    char status[SERVICE_STATUS_MAX_LEN];
    uint32_t call_count;
    bool stop_after_set_status;
    bool should_stop;
} ServiceState;

void service_state_init(ServiceState *state, bool stop_after_set_status);

DBusHandlerResult service_message_handler(
    DBusConnection *connection,
    DBusMessage *message,
    void *user_data
);

bool service_emit_status_changed(
    DBusConnection *connection,
    const char *old_status,
    const char *new_status
);

#endif /* ${PRO_UPPER}_SERVER_DBUS_SERVICE_H */
