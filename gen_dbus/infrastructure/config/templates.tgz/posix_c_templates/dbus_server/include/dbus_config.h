/* -*- Mode: C; indent-tabs-mode: nil; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * dbus_config.h
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

#ifndef ${PRO_UPPER}_SERVER_DBUS_CONFIG_H
#define ${PRO_UPPER}_SERVER_DBUS_CONFIG_H

#include <dbus/dbus.h>

static const DBusBusType SERVICE_BUS_TYPE = ${C_BUS_CONST};
static const char SERVICE_BUS_NAME[] = "org.vroncevic.${PRO_LOWER}.Service";
static const char SERVICE_OBJECT_PATH[] = "/org/vroncevic/${PRO_LOWER}/Object";
static const char SERVICE_INTERFACE[] = "org.vroncevic.${PRO_LOWER}.Control";

static const char SERVICE_INTROSPECT_XML[] =
    "<!DOCTYPE node PUBLIC \"-//freedesktop//DTD D-Bus Object Introspection 1.0//EN\"\n"
    " \"http://www.freedesktop.org/standards/dbus/1.0/introspect.dtd\">\n"
    "<node name=\"/org/vroncevic/${PRO_LOWER}/Object\">\n"
    "  <interface name=\"org.freedesktop.DBus.Introspectable\">\n"
    "    <method name=\"Introspect\">\n"
    "      <arg name=\"xml_data\" type=\"s\" direction=\"out\"/>\n"
    "    </method>\n"
    "  </interface>\n"
    "  <interface name=\"org.freedesktop.DBus.Peer\">\n"
    "    <method name=\"Ping\"/>\n"
    "  </interface>\n"
    "  <interface name=\"org.freedesktop.DBus.Properties\">\n"
    "    <method name=\"Get\">\n"
    "      <arg name=\"interface_name\" type=\"s\" direction=\"in\"/>\n"
    "      <arg name=\"property_name\" type=\"s\" direction=\"in\"/>\n"
    "      <arg name=\"value\" type=\"v\" direction=\"out\"/>\n"
    "    </method>\n"
    "    <method name=\"Set\">\n"
    "      <arg name=\"interface_name\" type=\"s\" direction=\"in\"/>\n"
    "      <arg name=\"property_name\" type=\"s\" direction=\"in\"/>\n"
    "      <arg name=\"value\" type=\"v\" direction=\"in\"/>\n"
    "    </method>\n"
    "    <method name=\"GetAll\">\n"
    "      <arg name=\"interface_name\" type=\"s\" direction=\"in\"/>\n"
    "      <arg name=\"props\" type=\"a{sv}\" direction=\"out\"/>\n"
    "    </method>\n"
    "    <signal name=\"PropertiesChanged\">\n"
    "      <arg name=\"interface_name\" type=\"s\"/>\n"
    "      <arg name=\"changed_properties\" type=\"a{sv}\"/>\n"
    "      <arg name=\"invalidated_properties\" type=\"as\"/>\n"
    "    </signal>\n"
    "  </interface>\n"
    "  <interface name=\"org.vroncevic.${PRO_LOWER}.Control\">\n"
    "    <method name=\"Ping\">\n"
    "      <arg name=\"message\" type=\"s\" direction=\"in\"/>\n"
    "      <arg name=\"reply\" type=\"s\" direction=\"out\"/>\n"
    "    </method>\n"
    "    <method name=\"SetStatus\">\n"
    "      <arg name=\"new_status\" type=\"s\" direction=\"in\"/>\n"
    "      <arg name=\"applied\" type=\"b\" direction=\"out\"/>\n"
    "    </method>\n"
    "    <property name=\"Status\" type=\"s\" access=\"readwrite\"/>\n"
    "    <property name=\"CallCount\" type=\"u\" access=\"read\"/>\n"
    "    <signal name=\"StatusChanged\">\n"
    "      <arg name=\"old_status\" type=\"s\"/>\n"
    "      <arg name=\"new_status\" type=\"s\"/>\n"
    "    </signal>\n"
    "  </interface>\n"
    "</node>\n";

#endif /* ${PRO_UPPER}_SERVER_DBUS_CONFIG_H */
