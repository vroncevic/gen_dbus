add_executable(${PRO_LOWER}_client
    src/dbus_proxy.c
    src/main.c
)

target_include_directories(${PRO_LOWER}_client PRIVATE
    "$${CMAKE_CURRENT_SOURCE_DIR}/include"
)

target_compile_options(${PRO_LOWER}_client PRIVATE -Wall -Wextra -Wpedantic)
target_link_libraries(${PRO_LOWER}_client PRIVATE PkgConfig::DBUS)
