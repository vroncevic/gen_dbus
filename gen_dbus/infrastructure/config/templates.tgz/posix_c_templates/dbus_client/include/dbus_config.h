/* -*- Mode: C; indent-tabs-mode: nil; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * dbus_config.h
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 */

#ifndef ${PRO_UPPER}_CLIENT_DBUS_CONFIG_H
#define ${PRO_UPPER}_CLIENT_DBUS_CONFIG_H

#include <dbus/dbus.h>

static const DBusBusType CLIENT_BUS_TYPE = ${C_BUS_CONST};
static const char SERVICE_BUS_NAME[] = "org.vroncevic.${PRO_LOWER}.Service";
static const char SERVICE_OBJECT_PATH[] = "/org/vroncevic/${PRO_LOWER}/Object";
static const char SERVICE_INTERFACE[] = "org.vroncevic.${PRO_LOWER}.Control";

#endif /* ${PRO_UPPER}_CLIENT_DBUS_CONFIG_H */
