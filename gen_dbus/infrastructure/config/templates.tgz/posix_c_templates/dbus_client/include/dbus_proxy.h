/* -*- Mode: C; indent-tabs-mode: nil; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * dbus_proxy.h
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 */

#ifndef ${PRO_UPPER}_CLIENT_DBUS_PROXY_H
#define ${PRO_UPPER}_CLIENT_DBUS_PROXY_H

#include <dbus/dbus.h>
#include <stdbool.h>
#include <stddef.h>

bool proxy_subscribe_signals(DBusConnection *conn);
bool proxy_introspect(DBusConnection *conn, char *out_buf, size_t out_size);
bool proxy_get_status_property(DBusConnection *conn, char *out_buf, size_t out_size);
bool proxy_ping(DBusConnection *conn, const char *message, char *out_buf, size_t out_size);
bool proxy_set_status(DBusConnection *conn, const char *new_status, bool *out_applied);
bool proxy_wait_status_signal(
    DBusConnection *conn,
    int timeout_ms,
    char *old_buf,
    size_t old_size,
    char *new_buf,
    size_t new_size
);

#endif /* ${PRO_UPPER}_CLIENT_DBUS_PROXY_H */
