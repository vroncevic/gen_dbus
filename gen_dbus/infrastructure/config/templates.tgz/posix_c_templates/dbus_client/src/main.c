/* -*- Mode: C; indent-tabs-mode: nil; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * main.c
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 */

#include "dbus_config.h"
#include "dbus_proxy.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void) {
    DBusError err;
    dbus_error_init(&err);

    DBusConnection *conn = dbus_bus_get(CLIENT_BUS_TYPE, &err);
    if (dbus_error_is_set(&err) || conn == NULL) {
        fprintf(stderr, "[client] D-Bus connection error: %s\n", err.message);
        dbus_error_free(&err);
        return EXIT_FAILURE;
    }

    if (!proxy_subscribe_signals(conn)) {
        dbus_connection_unref(conn);
        return EXIT_FAILURE;
    }

    char xml_buf[4096];
    if (!proxy_introspect(conn, xml_buf, sizeof(xml_buf))) {
        dbus_connection_unref(conn);
        return EXIT_FAILURE;
    }
    printf("[client] Introspection XML received (%zu bytes)\n", strlen(xml_buf));

    char status_buf[128];
    if (!proxy_get_status_property(conn, status_buf, sizeof(status_buf))) {
        dbus_connection_unref(conn);
        return EXIT_FAILURE;
    }
    printf("[client] Initial Property Status = '%s'\n", status_buf);

    char ping_reply[256];
    if (!proxy_ping(conn, "Hello from C11 client", ping_reply, sizeof(ping_reply))) {
        dbus_connection_unref(conn);
        return EXIT_FAILURE;
    }
    printf("[client] Ping reply: %s\n", ping_reply);

    bool applied = false;
    if (!proxy_set_status(conn, "ACTIVE", &applied) || !applied) {
        dbus_connection_unref(conn);
        return EXIT_FAILURE;
    }
    printf("[client] SetStatus('ACTIVE') applied = true\n");

    char old_status[128];
    char new_status[128];
    if (proxy_wait_status_signal(
            conn, 1500, old_status, sizeof(old_status), new_status, sizeof(new_status))) {
        printf(
            "[client] Signal StatusChanged: '%s' -> '%s'\n",
            old_status,
            new_status
        );
    }

    dbus_connection_unref(conn);
    return EXIT_SUCCESS;
}
