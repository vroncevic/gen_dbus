/* -*- Mode: C; indent-tabs-mode: nil; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * dbus_proxy.c
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 */

#include "dbus_proxy.h"
#include "dbus_config.h"

#include <stdio.h>
#include <string.h>

static const int DEFAULT_CALL_TIMEOUT_MS = 3000;

bool proxy_subscribe_signals(DBusConnection *conn) {
    DBusError err;
    dbus_error_init(&err);

    char rule[256];
    snprintf(
        rule,
        sizeof(rule),
        "type='signal',interface='%s',member='StatusChanged',path='%s'",
        SERVICE_INTERFACE,
        SERVICE_OBJECT_PATH
    );

    dbus_bus_add_match(conn, rule, &err);
    dbus_connection_flush(conn);
    if (dbus_error_is_set(&err)) {
        fprintf(stderr, "[client] Failed to subscribe signal: %s\n", err.message);
        dbus_error_free(&err);
        return false;
    }
    return true;
}

bool proxy_introspect(DBusConnection *conn, char *out_buf, size_t out_size) {
    DBusMessage *msg = dbus_message_new_method_call(
        SERVICE_BUS_NAME,
        SERVICE_OBJECT_PATH,
        DBUS_INTERFACE_INTROSPECTABLE,
        "Introspect"
    );
    if (msg == NULL) {
        return false;
    }

    DBusError err;
    dbus_error_init(&err);
    DBusMessage *reply = dbus_connection_send_with_reply_and_block(
        conn, msg, DEFAULT_CALL_TIMEOUT_MS, &err
    );
    dbus_message_unref(msg);

    if (dbus_error_is_set(&err) || reply == NULL) {
        fprintf(stderr, "[client] Introspect failed: %s\n", err.message);
        dbus_error_free(&err);
        return false;
    }

    const char *xml = NULL;
    bool ok = dbus_message_get_args(
        reply, &err, DBUS_TYPE_STRING, &xml, DBUS_TYPE_INVALID
    ) != FALSE;
    if (ok && xml != NULL) {
        snprintf(out_buf, out_size, "%s", xml);
    } else {
        dbus_error_free(&err);
    }
    dbus_message_unref(reply);
    return ok;
}

bool proxy_get_status_property(DBusConnection *conn, char *out_buf, size_t out_size) {
    DBusMessage *msg = dbus_message_new_method_call(
        SERVICE_BUS_NAME,
        SERVICE_OBJECT_PATH,
        DBUS_INTERFACE_PROPERTIES,
        "Get"
    );
    if (msg == NULL) {
        return false;
    }

    const char *iface = SERVICE_INTERFACE;
    const char *prop = "Status";
    dbus_message_append_args(
        msg,
        DBUS_TYPE_STRING, &iface,
        DBUS_TYPE_STRING, &prop,
        DBUS_TYPE_INVALID
    );

    DBusError err;
    dbus_error_init(&err);
    DBusMessage *reply = dbus_connection_send_with_reply_and_block(
        conn, msg, DEFAULT_CALL_TIMEOUT_MS, &err
    );
    dbus_message_unref(msg);

    if (dbus_error_is_set(&err) || reply == NULL) {
        fprintf(stderr, "[client] Properties.Get failed: %s\n", err.message);
        dbus_error_free(&err);
        return false;
    }

    DBusMessageIter iter;
    bool ok = false;
    if (dbus_message_iter_init(reply, &iter) &&
        dbus_message_iter_get_arg_type(&iter) == DBUS_TYPE_VARIANT) {
        DBusMessageIter variant;
        dbus_message_iter_recurse(&iter, &variant);
        if (dbus_message_iter_get_arg_type(&variant) == DBUS_TYPE_STRING) {
            const char *val = NULL;
            dbus_message_iter_get_basic(&variant, &val);
            snprintf(out_buf, out_size, "%s", val != NULL ? val : "");
            ok = true;
        }
    }
    dbus_message_unref(reply);
    return ok;
}

bool proxy_ping(
    DBusConnection *conn,
    const char *message,
    char *out_buf,
    size_t out_size
) {
    DBusMessage *msg = dbus_message_new_method_call(
        SERVICE_BUS_NAME,
        SERVICE_OBJECT_PATH,
        SERVICE_INTERFACE,
        "Ping"
    );
    if (msg == NULL) {
        return false;
    }

    dbus_message_append_args(msg, DBUS_TYPE_STRING, &message, DBUS_TYPE_INVALID);

    DBusError err;
    dbus_error_init(&err);
    DBusMessage *reply = dbus_connection_send_with_reply_and_block(
        conn, msg, DEFAULT_CALL_TIMEOUT_MS, &err
    );
    dbus_message_unref(msg);

    if (dbus_error_is_set(&err) || reply == NULL) {
        fprintf(stderr, "[client] Ping failed: %s\n", err.message);
        dbus_error_free(&err);
        return false;
    }

    const char *resp = NULL;
    bool ok = dbus_message_get_args(
        reply, &err, DBUS_TYPE_STRING, &resp, DBUS_TYPE_INVALID
    ) != FALSE;
    if (ok && resp != NULL) {
        snprintf(out_buf, out_size, "%s", resp);
    } else {
        dbus_error_free(&err);
    }
    dbus_message_unref(reply);
    return ok;
}

bool proxy_set_status(
    DBusConnection *conn,
    const char *new_status,
    bool *out_applied
) {
    DBusMessage *msg = dbus_message_new_method_call(
        SERVICE_BUS_NAME,
        SERVICE_OBJECT_PATH,
        SERVICE_INTERFACE,
        "SetStatus"
    );
    if (msg == NULL) {
        return false;
    }

    dbus_message_append_args(msg, DBUS_TYPE_STRING, &new_status, DBUS_TYPE_INVALID);

    DBusError err;
    dbus_error_init(&err);
    DBusMessage *reply = dbus_connection_send_with_reply_and_block(
        conn, msg, DEFAULT_CALL_TIMEOUT_MS, &err
    );
    dbus_message_unref(msg);

    if (dbus_error_is_set(&err) || reply == NULL) {
        fprintf(stderr, "[client] SetStatus failed: %s\n", err.message);
        dbus_error_free(&err);
        return false;
    }

    dbus_bool_t applied = FALSE;
    bool ok = dbus_message_get_args(
        reply, &err, DBUS_TYPE_BOOLEAN, &applied, DBUS_TYPE_INVALID
    ) != FALSE;
    if (ok && out_applied != NULL) {
        *out_applied = (applied != FALSE);
    } else if (!ok) {
        dbus_error_free(&err);
    }
    dbus_message_unref(reply);
    return ok;
}

bool proxy_wait_status_signal(
    DBusConnection *conn,
    int timeout_ms,
    char *old_buf,
    size_t old_size,
    char *new_buf,
    size_t new_size
) {
    int remaining = timeout_ms;
    const int step_ms = 100;

    while (remaining >= 0) {
        dbus_connection_read_write(conn, step_ms);
        DBusMessage *msg = dbus_connection_pop_message(conn);
        while (msg != NULL) {
            if (dbus_message_is_signal(msg, SERVICE_INTERFACE, "StatusChanged")) {
                DBusError err;
                dbus_error_init(&err);
                const char *old_val = NULL;
                const char *new_val = NULL;
                if (dbus_message_get_args(
                        msg, &err,
                        DBUS_TYPE_STRING, &old_val,
                        DBUS_TYPE_STRING, &new_val,
                        DBUS_TYPE_INVALID)) {
                    snprintf(old_buf, old_size, "%s", old_val != NULL ? old_val : "");
                    snprintf(new_buf, new_size, "%s", new_val != NULL ? new_val : "");
                    dbus_message_unref(msg);
                    return true;
                }
                dbus_error_free(&err);
            }
            dbus_message_unref(msg);
            msg = dbus_connection_pop_message(conn);
        }
        remaining -= step_ms;
    }
    return false;
}
