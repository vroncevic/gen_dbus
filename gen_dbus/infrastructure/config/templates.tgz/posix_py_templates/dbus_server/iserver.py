# -*- coding: UTF-8 -*-

'''
Module
    iserver.py
Copyright
    Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PRO} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PRO} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines IDBusServer structural protocol interface.
'''

from __future__ import annotations

from typing import Protocol, runtime_checkable

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://www.gnu.org/licenses/gpl-3.0.html'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


@runtime_checkable
class IDBusServer(Protocol):
    '''
        Defines structural protocol IDBusServer for D-Bus server lifecycle.

        It defines:

            :attributes:
                | None.
            :methods:
                | serve - Connects to D-Bus and serves object requests.
                | stop - Signals server loop to terminate gracefully.
    '''

    async def serve(self, *, once_mode: bool = False) -> bool:
        '''
            Connects to bus, exports interface, and processes requests.

            :param once_mode: Exit automatically after demo sequence.
            :return: True on clean shutdown, False otherwise.
        '''

    def stop(self) -> None:
        '''
            Signals server loop to terminate gracefully.

            :return: None.
        '''
