# -*- coding: UTF-8 -*-

'''
Module
    properties_base.py
Copyright
    Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PRO} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PRO} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines PropertiesBase exposing Status and CallCount D-Bus properties.
'''

from __future__ import annotations

from asyncio import Event

from dbus_fast import PropertyAccess
from dbus_fast.service import ServiceInterface, dbus_property

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://www.gnu.org/licenses/gpl-3.0.html'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class PropertiesBase(ServiceInterface):
    '''
        Defines class PropertiesBase with Status and CallCount properties.

        It defines:

            :attributes:
                | _status - Current service status string.
                | _call_count - Total processed control operations.
                | _once_mode - Whether server stops after demo sequence.
                | _stop_event - Asyncio event signaling shutdown.
            :methods:
                | __init__ - Initializes PropertiesBase constructor.
                | status_prop - Gets or sets Status D-Bus property.
                | call_count_prop - Gets read-only CallCount D-Bus property.
                | apply_status_transition - Updates status and notifies bus.
    '''

    def __init__(
        self,
        interface_name: str,
        *,
        stop_event: Event,
        once_mode: bool = False
    ) -> None:
        '''
            Initializes PropertiesBase constructor.

            :param interface_name: Exported D-Bus interface name.
            :param stop_event: Event set when once_mode threshold is reached.
            :param once_mode: Whether server stops automatically after demo.
            :exceptions: None.
        '''
        super().__init__(interface_name)
        self._status: str = 'idle'
        self._call_count: int = 0
        self._once_mode: bool = once_mode
        self._stop_event: Event = stop_event

    @dbus_property(name='Status', access=PropertyAccess.READWRITE)
    def status_prop(self) -> 's':
        '''
            Returns current Status property value.

            :return: Current status string.
            :exceptions: None.
        '''
        return self._status

    @status_prop.setter
    def status_prop(self, value: 's') -> None:
        '''
            Updates Status property via org.freedesktop.DBus.Properties.Set.

            :param value: New status string.
            :exceptions: None.
        '''
        self.apply_status_transition(value)

    @dbus_property(name='CallCount', access=PropertyAccess.READ)
    def call_count_prop(self) -> 'u':
        '''
            Returns read-only CallCount property value.

            :return: Total processed control operations.
            :exceptions: None.
        '''
        return self._call_count

    def apply_status_transition(self, next_status: str) -> None:
        '''
            Applies status update and emits PropertiesChanged notification.

            :param next_status: Target status string.
            :exceptions: None.
        '''
        self._status = next_status
        self._call_count += 1
        self.emit_properties_changed(
            {'Status': self._status, 'CallCount': self._call_count}
        )
        if self._once_mode and self._call_count >= 3:
            self._stop_event.set()
