# -*- coding: UTF-8 -*-

'''
Module
    config.py
Copyright
    Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PRO} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PRO} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines ServerConfig immutable D-Bus endpoint configuration.
'''

from __future__ import annotations

from dataclasses import dataclass
from dbus_fast import BusType

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://www.gnu.org/licenses/gpl-3.0.html'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


@dataclass(frozen=True, slots=True)
class ServerConfig:
    '''
        Defines class ServerConfig immutable endpoint configuration.

        It defines:

            :attributes:
                | bus_type - D-Bus bus type (SESSION or SYSTEM).
                | bus_name - Well-known D-Bus service name.
                | object_path - Exported D-Bus object path.
                | interface_name - Exported D-Bus interface name.
            :methods:
                | default - Creates default ServerConfig instance.
    '''

    bus_type: BusType
    bus_name: str
    object_path: str
    interface_name: str

    @classmethod
    def default(cls) -> ServerConfig:
        '''
            Creates default ServerConfig for ${PRO} service.

            :return: Configured ServerConfig instance.
            :exceptions: None.
        '''
        return cls(
            bus_type=BusType.${PY_BUS_CONST},
            bus_name='org.vroncevic.${PRO_LOWER}.Service',
            object_path='/org/vroncevic/${PRO_LOWER}/Object',
            interface_name='org.vroncevic.${PRO_LOWER}.Control'
        )
