# -*- coding: UTF-8 -*-

'''
Module
    main.py
Copyright
    Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PRO} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PRO} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Entrypoint script for ${PRO} Python D-Bus server.
'''

from __future__ import annotations

from asyncio import run
from sys import argv, exit as sys_exit

from dbus_server.factory import ServerFactory
from dbus_server.iserver import IDBusServer

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://www.gnu.org/licenses/gpl-3.0.html'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


def main() -> bool:
    '''
        Bootstraps and runs ${PRO} D-Bus server.

        :return: True on clean exit, False otherwise.
        :exceptions: None.
    '''
    once_mode: bool = '--once' in argv[1:]
    server: IDBusServer = ServerFactory.create()
    try:
        return run(server.serve(once_mode=once_mode))
    except KeyboardInterrupt:
        server.stop()
        return True


if __name__ == '__main__':
    sys_exit(0 if main() else 1)
