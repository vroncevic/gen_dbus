# -*- coding: UTF-8 -*-

'''
Module
    interface.py
Copyright
    Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PRO} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PRO} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines ControlInterface exporting Ping, SetStatus, and StatusChanged.
'''

from __future__ import annotations

from dbus_fast.service import method, signal

from dbus_server.properties_base import PropertiesBase

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://www.gnu.org/licenses/gpl-3.0.html'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class ControlInterface(PropertiesBase):
    '''
        Defines class ControlInterface for org.vroncevic.${PRO_LOWER}.Control.

        It defines:

            :attributes:
                | None (inherits state from PropertiesBase).
            :methods:
                | ping - Handles Ping(s) -> (s) method call.
                | set_status - Handles SetStatus(s) -> (b) method call.
                | status_changed - Emits StatusChanged(ss) D-Bus signal.
                | apply_status_transition - Emits StatusChanged + PropertiesChanged.
    '''

    @method(name='Ping')
    def ping(self, message: 's') -> 's':
        '''
            Replies to Ping method call and increments CallCount.

            :param message: Client ping payload.
            :return: Formatted pong response.
            :exceptions: None.
        '''
        self._call_count += 1
        self.emit_properties_changed({'CallCount': self._call_count})
        if self._once_mode and self._call_count >= 3:
            self._stop_event.set()
        return f'[${PRO}] pong: {message}'

    @method(name='SetStatus')
    def set_status(self, new_status: 's') -> 'b':
        '''
            Updates service status and emits StatusChanged signal.

            :param new_status: Requested status value.
            :return: True when status transition is applied.
            :exceptions: None.
        '''
        self.apply_status_transition(new_status)
        return True

    @signal(name='StatusChanged')
    def status_changed(self, old_status: str, new_status: str) -> 'ss':
        '''
            Broadcasts StatusChanged(old_status, new_status) D-Bus signal.

            :param old_status: Previous status string.
            :param new_status: Updated status string.
            :return: Two-element list serialized as (ss).
            :exceptions: None.
        '''
        return [old_status, new_status]

    def apply_status_transition(self, next_status: str) -> None:
        '''
            Emits StatusChanged signal and delegates property update.

            :param next_status: Target status string.
            :exceptions: None.
        '''
        previous: str = self._status
        super().apply_status_transition(next_status)
        self.status_changed(previous, next_status)
