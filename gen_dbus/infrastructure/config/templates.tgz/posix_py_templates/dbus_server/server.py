# -*- coding: UTF-8 -*-

'''
Module
    server.py
Copyright
    Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PRO} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PRO} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines DBusServer concrete implementation of IDBusServer contract.
'''

from __future__ import annotations

from asyncio import Event, sleep
from sys import stdout

from dbus_fast.aio import MessageBus

from dbus_server.config import ServerConfig
from dbus_server.interface import ControlInterface

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://www.gnu.org/licenses/gpl-3.0.html'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class DBusServer:
    '''
        Defines class DBusServer implementing IDBusServer structurally.

        It defines:

            :attributes:
                | _config - Immutable ServerConfig instance.
                | _stop_event - Asyncio event controlling server lifecycle.
            :methods:
                | __init__ - Initializes DBusServer constructor.
                | serve - Exports ControlInterface and awaits shutdown.
                | stop - Signals graceful shutdown.
    '''

    def __init__(self, config: ServerConfig) -> None:
        '''
            Initializes DBusServer constructor.

            :param config: D-Bus server endpoint configuration.
            :exceptions: None.
        '''
        self._config: ServerConfig = config
        self._stop_event: Event = Event()

    async def serve(self, *, once_mode: bool = False) -> bool:
        '''
            Connects to D-Bus, exports object, and serves until stopped.

            :param once_mode: Automatically stop after demo call threshold.
            :return: True on graceful completion.
            :exceptions: None.
        '''
        bus: MessageBus = await MessageBus(
            bus_type=self._config.bus_type
        ).connect()
        interface: ControlInterface = ControlInterface(
            self._config.interface_name,
            stop_event=self._stop_event,
            once_mode=once_mode
        )
        bus.export(self._config.object_path, interface)
        await bus.request_name(self._config.bus_name)
        stdout.write(
            f'[server] Ready on {self._config.bus_name} '
            f'({self._config.object_path})\n'
        )
        stdout.flush()
        await self._stop_event.wait()
        await sleep(0.1)
        bus.disconnect()
        return True

    def stop(self) -> None:
        '''
            Signals server loop to terminate gracefully.

            :return: None.
            :exceptions: None.
        '''
        self._stop_event.set()
