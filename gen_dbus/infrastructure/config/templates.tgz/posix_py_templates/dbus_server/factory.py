# -*- coding: UTF-8 -*-

'''
Module
    factory.py
Copyright
    Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PRO} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PRO} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines ServerFactory wiring D-Bus server subsystem.
'''

from __future__ import annotations

from dbus_server.config import ServerConfig
from dbus_server.iserver import IDBusServer
from dbus_server.server import DBusServer

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://www.gnu.org/licenses/gpl-3.0.html'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class ServerFactory:
    '''
        Defines class ServerFactory wiring DBusServer instances.

        It defines:

            :attributes:
                | None.
            :methods:
                | create - Creates configured IDBusServer instance.
                | get_version - Returns factory module version.
    '''

    @classmethod
    def create(cls) -> IDBusServer:
        '''
            Creates default IDBusServer instance.

            :return: Configured IDBusServer adapter.
            :exceptions: None.
        '''
        return DBusServer(ServerConfig.default())

    @classmethod
    def get_version(cls) -> str:
        '''
            Returns module version string.

            :return: Version string.
            :exceptions: None.
        '''
        return __version__
