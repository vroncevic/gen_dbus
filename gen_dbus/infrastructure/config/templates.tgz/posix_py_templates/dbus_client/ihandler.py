# -*- coding: UTF-8 -*-

'''
Module
    ihandler.py
Copyright
    Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PRO} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PRO} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines ISignalHandler structural protocol for StatusChanged signals.
'''

from __future__ import annotations

from typing import Protocol, runtime_checkable

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://www.gnu.org/licenses/gpl-3.0.html'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


@runtime_checkable
class ISignalHandler(Protocol):
    '''
        Defines structural protocol ISignalHandler for StatusChanged events.

        It defines:

            :attributes:
                | None.
            :methods:
                | on_status_changed - Handles StatusChanged(old, new) signal.
                | get_received_count - Returns number of signals observed.
    '''

    def on_status_changed(self, old_status: str, new_status: str) -> None:
        '''
            Handles StatusChanged signal emitted by remote D-Bus object.

            :param old_status: Previous status string.
            :param new_status: New status string.
            :return: None.
        '''

    def get_received_count(self) -> int:
        '''
            Returns total received StatusChanged signal count.

            :return: Signal count.
        '''
