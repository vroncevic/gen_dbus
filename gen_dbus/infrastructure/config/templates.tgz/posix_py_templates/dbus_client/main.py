# -*- coding: UTF-8 -*-

'''
Module
    main.py
Copyright
    Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PRO} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PRO} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Entrypoint script for ${PRO} Python D-Bus client.
'''

from __future__ import annotations

from asyncio import run
from sys import exit as sys_exit

from dbus_client.factory import ClientFactory
from dbus_client.iclient import IDBusClient

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://www.gnu.org/licenses/gpl-3.0.html'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


def main() -> bool:
    '''
        Bootstraps and runs ${PRO} D-Bus client session.

        :return: True when client session succeeds, False otherwise.
        :exceptions: None.
    '''
    client: IDBusClient = ClientFactory.create()
    return run(client.run_session())


if __name__ == '__main__':
    sys_exit(0 if main() else 1)
