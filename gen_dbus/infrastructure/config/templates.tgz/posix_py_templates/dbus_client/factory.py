# -*- coding: UTF-8 -*-

'''
Module
    factory.py
Copyright
    Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PRO} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PRO} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines ClientFactory wiring D-Bus client subsystem.
'''

from __future__ import annotations

from dbus_client.client import DBusClient
from dbus_client.config import ClientConfig
from dbus_client.handler import SignalHandler
from dbus_client.iclient import IDBusClient

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://www.gnu.org/licenses/gpl-3.0.html'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class ClientFactory:
    '''
        Defines class ClientFactory wiring DBusClient instances.

        It defines:

            :attributes:
                | None.
            :methods:
                | create - Creates configured IDBusClient instance.
                | get_version - Returns factory module version.
    '''

    @classmethod
    def create(cls) -> IDBusClient:
        '''
            Creates default IDBusClient instance with SignalHandler.

            :return: Configured IDBusClient adapter.
            :exceptions: None.
        '''
        return DBusClient(ClientConfig.default(), SignalHandler())

    @classmethod
    def get_version(cls) -> str:
        '''
            Returns module version string.

            :return: Version string.
            :exceptions: None.
        '''
        return __version__
