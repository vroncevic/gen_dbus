# -*- coding: UTF-8 -*-

'''
Module
    handler.py
Copyright
    Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PRO} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PRO} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines SignalHandler concrete observer for StatusChanged signals.
'''

from __future__ import annotations

from sys import stdout

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://www.gnu.org/licenses/gpl-3.0.html'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class SignalHandler:
    '''
        Defines class SignalHandler implementing ISignalHandler structurally.

        It defines:

            :attributes:
                | _received_count - Counter of observed StatusChanged signals.
            :methods:
                | __init__ - Initializes SignalHandler constructor.
                | on_status_changed - Logs incoming StatusChanged signal.
                | get_received_count - Returns observed signal count.
    '''

    def __init__(self) -> None:
        '''
            Initializes SignalHandler constructor.

            :exceptions: None.
        '''
        self._received_count: int = 0

    def on_status_changed(self, old_status: str, new_status: str) -> None:
        '''
            Logs StatusChanged signal transition to standard output.

            :param old_status: Previous status string.
            :param new_status: Updated status string.
            :exceptions: None.
        '''
        self._received_count += 1
        stdout.write(
            f"[client] Signal StatusChanged: '{old_status}' -> '{new_status}'\n"
        )
        stdout.flush()

    def get_received_count(self) -> int:
        '''
            Returns total received StatusChanged signal count.

            :return: Observed signal count.
            :exceptions: None.
        '''
        return self._received_count
