# -*- coding: UTF-8 -*-

'''
Module
    client.py
Copyright
    Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PRO} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PRO} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines DBusClient concrete implementation of IDBusClient contract.
'''

from __future__ import annotations

from asyncio import sleep
from sys import stdout

from dbus_fast.aio import MessageBus, ProxyInterface, ProxyObject
from dbus_fast.introspection import Node

from dbus_client.config import ClientConfig
from dbus_client.ihandler import ISignalHandler

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://www.gnu.org/licenses/gpl-3.0.html'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class DBusClient:
    '''
        Defines class DBusClient implementing IDBusClient structurally.

        It defines:

            :attributes:
                | _config - Immutable ClientConfig target descriptor.
                | _handler - Injected ISignalHandler observer.
            :methods:
                | __init__ - Initializes DBusClient constructor.
                | run_session - Runs Introspect, Ping, SetStatus, Properties, and Signals.
                | get_config - Returns immutable client configuration.
    '''

    def __init__(self, config: ClientConfig, handler: ISignalHandler) -> None:
        '''
            Initializes DBusClient constructor.

            :param config: Target D-Bus service configuration.
            :param handler: Signal handler delegate.
            :exceptions: None.
        '''
        self._config: ClientConfig = config
        self._handler: ISignalHandler = handler

    def get_config(self) -> ClientConfig:
        '''
            Returns immutable client configuration.

            :return: Configured ClientConfig instance.
            :exceptions: None.
        '''
        return self._config

    async def run_session(self) -> bool:
        '''
            Connects to remote D-Bus object and exercises all IPC features.

            :return: True when all interactions complete cleanly.
            :exceptions: None.
        '''
        bus: MessageBus = await MessageBus(
            bus_type=self._config.bus_type
        ).connect()
        introspection: Node = await bus.introspect(
            self._config.bus_name, self._config.object_path
        )
        stdout.write(
            f'[client] Introspected interfaces: '
            f'{len(introspection.interfaces)}\n'
        )
        proxy_obj: ProxyObject = bus.get_proxy_object(
            self._config.bus_name, self._config.object_path, introspection
        )
        control: ProxyInterface = proxy_obj.get_interface(
            self._config.interface_name
        )
        control.on_status_changed(self._handler.on_status_changed)

        initial_status: str = await control.get_status()
        stdout.write(f'[client] Initial Status property: {initial_status}\n')

        pong: str = await control.call_ping('hello from Python 3.12+ client')
        stdout.write(f'[client] Ping reply: {pong}\n')

        applied: bool = await control.call_set_status('active')
        stdout.write(f"[client] SetStatus('active') applied: {applied}\n")

        await control.set_status('ready')
        await sleep(0.08)

        final_status: str = await control.get_status()
        call_count: int = await control.get_call_count()
        stdout.write(
            f'[client] Final Status: {final_status} | '
            f'CallCount: {call_count} | '
            f'Signals: {self._handler.get_received_count()}\n'
        )
        stdout.flush()
        bus.disconnect()
        return True
