#!/usr/bin/env bash
set -euo pipefail
python3 -m dbus_client.main "$@"
